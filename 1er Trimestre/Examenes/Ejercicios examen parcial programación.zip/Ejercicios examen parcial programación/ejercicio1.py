#1
var1=float(input("Introduce el primer número"))
var2=float(input("Introduce el segundo número"))
vartotal=var1+var2
print("El resultado de la suma de",var1+var2,"es igual a",vartotal)

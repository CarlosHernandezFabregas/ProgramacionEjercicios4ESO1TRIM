#2
var1=float(input("Introduce el primer número"))
var2=float(input("introduce el segundo número"))
vartotal=var1+var2
print("El resultado de la suma de los dos números es",vartotal)
print("El resultado de dividir",vartotal,"entre 3 es",vartotal/3)

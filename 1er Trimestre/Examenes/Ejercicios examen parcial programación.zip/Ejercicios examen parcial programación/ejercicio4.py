#4
print("****GASOLINERA****")
print("1.-Sin plomo 95")
print("2.- Sin plomo 98")
print("3.- Gasóleo A")
print("4.- Gasóleo A+")
print("******************")
var1=int(input("Introduce un número del 1 al 4"))
if var1==1:
    print("Has elegido la sin plomo 95.")
    numlitros=int(input("Introduce el número de litros"))
    print("El total a pagar es de",numlitros*1.765)
if var1==2:
    print("has elegido la sin plomo 98")
    numlitros2=int(input("Introduce el número de litros"))
    print("El total a pagar es de",(numlitros2*1.913)-(10/100*1.913))
if var1==3:
    print("Has elegido Gasóleo A, introduce un número de litros")
    numlitros3=float(input("Introduce el número de litros que quieres repostar"))
    print("El precio total es de",numlitros3*1.746)
if var1==4:
    print("Has elegido Gasóleo A+, introduce un número de litros")
    numlitros4=float(input("Introduce el número de litros que quieres repostar"))
    var3=(numlitros*1.839)+((-10/100)*1.839)
    print("El precio total es",(numlitros4*1.839-var3))
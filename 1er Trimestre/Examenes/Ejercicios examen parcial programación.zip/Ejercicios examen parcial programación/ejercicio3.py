#3
import math
var1=int(input("Intoduce el lado del triángulo equilatero"))
print ("El area del triángulo equilatero es", (math.sqrt(3)/4)*(var1**2))